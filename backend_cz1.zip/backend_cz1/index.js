const express = require("express");
const mysql = require("mysql");
const cors = require("cors");

const app = express();
app.use(cors()); // allow React to access backend

const PORT = 5001; // backend must NOT run on 3000

// MySQL connection
const con = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'PSP'
});



// MAIN API: return data from database
app.get("/api/punkty", (req, res) => {
  const sql = "SELECT * FROM Pozycja";

  con.query(sql, (error, result) => {
    if (error) {
      console.error(error);
      return res.status(500).json({ error: "Database error" });
    }
    res.json(result); // send SQL result to frontend
  });
});

// Example route
app.get("/api/hello", (req, res) => {
  res.json({ message: "Hello from Node backend!" });
});

app.listen(PORT, () => {
  console.log(`Backend server running on port ${PORT}`);
});