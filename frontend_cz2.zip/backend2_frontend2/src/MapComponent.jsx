import React, { useRef, useEffect } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';

let building = [ {
        "lat": 52.2297,
        "lon": 21.0122,
        "altitude_m": 110,
} ];

let firefighter = [ {
      "lat": 52.229859,
      "lon": 21.012597,
      "altitude_m": 112.1,
      "accuracy_m": 3.5,
      "fix": true,
      "satellites": 8
} ];

const MapComponent = () => {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);

  useEffect(() => {
    if (mapInstanceRef.current) return;

    mapInstanceRef.current = new maplibregl.Map({
      container: mapContainerRef.current,
      // Konfiguracja darmowej mapy OpenStreetMap (ulice, nazwy, obszary)
      style: {
        version: 8,
        sources: {
          'osm-tiles': {
            type: 'raster',
            tiles: [
              'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            ],
            tileSize: 256,
            attribution: '&copy; OpenStreetMap Contributors',
          },
        },
        layers: [
          {
            id: 'osm-tiles-layer',
            type: 'raster',
            source: 'osm-tiles',
            minzoom: 0,
            maxzoom: 19,
          },
        ],
      },
      center: [building[0].lon, building[0].lat], // Warszawa
      zoom: 13
    });

    firefighter.forEach(ff => {
    new maplibregl.Marker({ color: 'red' })
    .setLngLat([firefighter[0].lon, firefighter[0].lat])
    .setPopup(new maplibregl.Popup().setHTML(
      `<b>${firefighter[0].lon}</b><br>${firefighter[0].lat}<br>${ff.role}`
    ))
    .addTo(mapInstanceRef.current);
    });

    mapInstanceRef.current.addControl(new maplibregl.NavigationControl(), 'top-right');
    
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Usunąłem position: absolute, żeby było bezpieczniej dla layoutu
  return (
    <div 
      ref={mapContainerRef} 
      style={{ width: '100%', height: '100%', minHeight: '400px' }} 
    />
  );
};

export default MapComponent;